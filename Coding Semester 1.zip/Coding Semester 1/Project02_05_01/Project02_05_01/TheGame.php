<html>

<head>
    <!--
      Project 02_05_01

      Author: George Rautio

      Filename: TheGame.php
   -->
    <title>The Game</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body style="background-color: cyan;">
    <h2>The Game Login</h2>
    <hr>
    <?php       
    $dir = "./TheGamers";
    $password = " ";
//$Dir var has a path as a string to the comments folder
    if (is_dir($dir)){
        if(isset($_POST['save'])){
            if (empty($_POST['username'])) {
                echo "Unkown visitor\n";
            }
            else{
                $saveString = stripslashes($_POST['username'] . "\n");    
                $saveString .= stripslashes($_POST['name'] . "\n");
                $saveString .= stripslashes($_POST['email'] . "\n");
                $saveString .= stripslashes($_POST['screenname'] . "\n");
                $saveString .= stripslashes(md5($_POST['password'] .  "\n"));
                $saveString .= stripslashes($_POST['comments'] . "\n");


                    $saveFileName = "$dir/TheGamers.txt";
                if (file_put_contents($saveFileName, $saveString) > 0) {
                    echo"Gamer you are successfully loged in @ \"". htmlentities($saveFileName)  . "\"<br>\n";

                }
                else{
                    echo"There was an error loging in \"". htmlentities($saveFileName)  ."\".<br>\n";
                }
            }
        }
        
    }
   
    else{
echo "there was an error logging<br>";
    }
     

?>
        <form action="TheGame.php" method="post">
           Your username: <input type="text" name="username" required><br> 
            Your name: <input type="text" name="name" required><br>
            Your email: <input type="email" name="email" required><br>
            Your age: 
            <select>
                <?php for ($age=1; $age<=100; $age++){ ?>
            <option name="age" value="<?php echo $age;?>"> <?php echo $age;?></option><?php } ?>
            </select><br>
            Your screen name: <input type="text" name="screenname" required><br>
            Your password: <input type=password_hash() name="password" required><br>
            Comments: <textarea cols="20" placeholder="Your comments here" rows="1" name="comments" required></textarea><br>
            <input type="submit" name="save" value="Login"><br>
        </form>


</body>

</html>
