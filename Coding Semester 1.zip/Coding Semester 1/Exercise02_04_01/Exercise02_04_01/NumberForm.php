<html>

<head>
    <!--
      Exercise 02_04_01

      Author: George Rautio
      Date: November 13, 2017   

      Filename: NumberForm.php
   -->
    <meta charset="utf-8">
    <title>Number Form</title>
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>  
  </head>
  <body>
      <h2>Number Form</h2>
      <?php
 //Globals
       $displayForm = true;
       $number = "";
       if (isset($_POST['Submit'])) {
           $number = $_POST['number'];
           if (is_numeric($number)) {
               $displayForm = false;
           }
           else {
               echo "<p>You need to enter a numeric value</p>\n"; //This sends an error 
               $displayForm = true;
           }
       }
       if ($displayForm) { //if displayForm is true, then it will display the form
           ?>
           <form name="NumberForm" action="NumberForm.php" method="post">
               <p>
                   Enter a number:
                   <input type="text" name="number" value="<?php echo $number; ?>">
               </p>
               <p>
                   <input type="reset" value="Clear Form">&nbsp;&nbsp;
                   <input type="submit" value="Send Form" name="Submit">
               </p>
           </form>
      <?php
       }
       else {
          echo "<p>Thank you for entering a number</p>\n";
          echo "<p>your number, $number, squared is " . ($number * $number) . ".</p>\n";
          echo "<p><a href=\"NumberForm.php\">Try again?</a></p>\n";
      }
      ?>
  </body>
</html>