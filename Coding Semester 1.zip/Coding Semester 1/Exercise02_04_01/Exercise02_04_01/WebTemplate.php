<html>

<head>
    <!--
      Exercise 02_04_01

      Author: George Rautio
      Date: November 13, 2017   

      Filename: WebTemplate.php
   -->
    <title>WebTemplate</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
   
    <?php
    include("inc_Header.html");
    ?>
<div style="width:20%; text-align:center; float:left;">

    <?php include("inc_ButtonNav.html")
    ?>
</div>
    <!--Starts dynamic content section-->
    <?php 
    if(isset($_GET['content'])){
       switch ($_GET['content']){
           case 'About Me':     
               include("inc_About.html");
               break;
           case 'Contact Me':     
               include("inc_Contact.html");
               break;
           case 'Home':     
               include("inc_Home.html");
               break;
           default:     
               include("inc_Home.html");
               break;
       } 
    }
    else{//no button clicked
    include("inc_Home.html");
    }
    ?>
    <?php
    include("inc_Footer.php");
    ?>
</body>

</html>
