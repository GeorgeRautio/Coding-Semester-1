<html>

<head>
    <!--
      Exercise 02_04_01

      Author: George Rautio
      Date: November 13, 2017   

      Filename: Process_Scholarship2.php
   -->
    <title>Process Scholarship 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <?php
     $errorCount = 0;
// error message display function    
    function displayRequired($fieldName){
        echo"The field \"$fieldName\" is required.<br>";    
    }
// validate input function    
    function validateInput($data, $fieldName){
        global $errorCount;
        $retVal = "";
        if (empty($data)){
            displayRequired($fieldName);
            ++$errorCount;
            $retVal = "";
        }
        
        else {
            $retVal = trim($data);
            $retVal = stripslashes($retVal);
        }
//prosecss the data
        return $retVal;
    }
// redisplays the form as a sticky form  
    function redisplayForm($first, $last){
    ?>
    <h2 style="text-align: center">Process Scholarship 2</h2>
    <form name="scholarship" action="Process_Scholarship2.php" method="post">
    <p>First name: <input type="text" name="fName" value="<?php echo $first ?>"> </p>
    <p>Last name: <input type="text" name="lName" value=" <?php echo $last ?>"> </p>
        
        <p>
        <input type="reset" value="Clear Form">&nbsp;&nbsp;
        <input type="submit" value="Send Form">
        </p>
    
    </form>
    
    <?php
    
    }
   
    $firstName = validateInput($_POST['fName'], "First Name");
    $lastName =  validateInput($_POST['lName'], "Last Name");
//if statment that displays if they did not fill in a required area/errors
    if($errorCount > 0){
        echo "$errorCount error(s): Please re-enter the information below. <br>";
        redisplayForm($firstName,$lastName);
    }
// else statment displays thank you message    
    else{
       echo "Thank you for filling out the Scholarship form, $firstName $lastName. <br>"; 
    }
    
    
    
    ?>

</body>

</html>
