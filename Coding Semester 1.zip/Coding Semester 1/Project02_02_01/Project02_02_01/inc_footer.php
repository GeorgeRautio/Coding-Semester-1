<html>

<head>
    <!--
      Project 02_02_01

      Author: George Rautio
      Date: October 30, 2017   

      Filename: inc_footer.php
   -->
</head>

<body>
<hr>
<strong>Updated</strong>&nbsp;06 January, 2017<br>
&copy; 2017 by Coast City Computers<br>All Rights Reserved

</body>

</html>