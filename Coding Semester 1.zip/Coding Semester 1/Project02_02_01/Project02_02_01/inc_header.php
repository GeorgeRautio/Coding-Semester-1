<html>

<head>
    <!--
      Project 02_02_01

      Author: George Rautio
      Date: October 30, 2017   

      Filename: inc_header.php
   -->
</head>

<body>
<h1>Coast City Computers</h1>
<strong>Buy Online or Call 1-800-555-1212</strong>
<hr>
</body>

</html>