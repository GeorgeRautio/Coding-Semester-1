<html>

<head>
    <!--
      Project 02_02_01

      Author: George Rautio
      Date: October 26, 2017   

      Filename: OddNumbers.php
   -->
    <title>Odd Numbers</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
<h2>Odd Numbers</h2>
    <?php
//While loop that displays all the odd numbers from 1 to 100    
    $oddNumber = 1;
    while ( $oddNumber <= 100 ) {
    echo "$oddNumber<br />";
    $oddNumber += 2;
    }
    ?> 

</body>

</html>

