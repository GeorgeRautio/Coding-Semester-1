<html>

<head>
    <!--
      Project 02_02_01

      Author: George Rautio
      Date: October 30, 2017   

      Filename: TempConversion.php
   -->
    <title>Coast City Computers</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
   
<h2> Temp Conversion</h2>

<?php
//while loop that displays the ftemp "Fahrenhight" temp that is equal to the ctemp "celsius" temp by setting ftemp to be subtracted by 32 and multipleyed with (5/9) also .55
    
$fTemp = 0;
while ($fTemp <= 100) {
	$cTemp = ($fTemp - 32) * .55;
	echo $fTemp." Fahrenheit is equal to ".$cTemp." Celsius<br />"; 
	$fTemp++;
}
?>

 
</body>

</html>

