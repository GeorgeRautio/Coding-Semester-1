<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 17, 2017   

      Filename: DaysArray.php
   -->
    <title>Days Array</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Days Array</h2>
    <?php
//Varibles with the value of days in English
    $days[0]= "Sunday";
    $days[1]= "Monday";
    $days[2]= "Tuesday";
    $days[3]= "Wednesday";
    $days[4]= "Thursday";
    $days[5]= "Friday";
    $days[6]= "Saturday";
    
// The array that holds the days in English
     $days[] = array("$days[0] " . "$days[1] " . "$days[2] " . "$days[3] " . "$days[4] " . "$days[5]". "$days[6]" ); 
// Prints the days of the week in English    
     echo "<h3>The days of the week in English are:<br> " , "$days[0]<br> ", "$days[1]<br> " ,"$days[2]<br> " , "$days[3]<br> " , "$days[4]<br> " , "$days[5]<br> ", "$days[6]<br> ","</h3>";
//Varibles with the value of days in English
    $days[0]= "Dimanche";
    $days[1]= "Lundi";
    $days[2]= "Mardi";
    $days[3]= "Mercedi";
    $days[4]= "Jeudi";
    $days[5]= "Vendredi";
    $days[6]= "Samedi";   
    
// The array that holds the value of the day in French
    $days[] = array("$days[0] " . "$days[1] " . "$days[2] " . "$days[3] " . "$days[4] " . "$days[5]". "$days[6]" );     
// Prints the days of the week in French   
     echo "<h3>The days of the week in French are:<br> " , "$days[0]<br> ", "$days[1]<br> " ,"$days[2]<br> " , "$days[3]<br> " , "$days[4]<br> " , "$days[5]<br> ", "$days[6]<br> ","</h3>";
    ?>

</body>

</html>
