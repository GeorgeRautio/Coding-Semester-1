<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 17, 2017   

      Filename: IsEven.php
   -->
    <title>Is Even</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Is Even</h2>
    <?php   
//Outputs the numbers on top    
    echo 5,"<br>",22,"<br>", 9,"<br>", 2,"<br>", 11,"<br>", 37,"<br>", 44,"<br>", 8,"<br>", 82,"<br>", 12,"<br>","<br>";
//Array that holds the odd and even numbers
    $numbersArray = array('5','22','9','2','11','37','44','8','82','12');
//Outputs wehter the number on top is even or odd    
    foreach($numbersArray as $number){
 if ($number % 2 == 0) {
    echo "It is an even number.<br>";
} else {
    echo "It is an odd number.<br>";
        }
    }
    ?>

</body>

</html>
