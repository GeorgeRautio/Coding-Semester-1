<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 17, 2017   

      Filename: InterestArray.php
   -->
    <title>Interest Array</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h1>Interest Array</h1>
    <h2>Interest</h2>
    <?php
//Varibles with the value of the interest rates 
    $interestRate[1] = ".0725";
    $interestRate[2] = ".0750";
    $interestRate[3] = ".0775";
    $interestRate[4] = ".0800";
    $interestRate[5] = ".0825";
    $interestRate[6] = ".0850";
    $interestRate[7] = ".0875";
        
//The array that holds the interest rates         
 $interestRates[] = array("$interestRate[1]". "$interestRate[2]". "$interestRate[3]" . "$interestRate[4]" .  " $interestRate[5]". "$interestRate[6]" ."$interestRate[7]" );
 //Prints the interest rate from the varible in the arrays
    echo "$interestRate[1] <br>". "$interestRate[2] <br>"."$interestRate[3]<br>"."$interestRate[4] <br>"."$interestRate[5] <br>". "$interestRate[6]<br>"."$interestRate[7] <br>";
    ?>

</body>

</html>
