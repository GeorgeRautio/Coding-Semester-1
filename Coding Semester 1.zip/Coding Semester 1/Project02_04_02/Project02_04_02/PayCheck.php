<html>
<head>
     <!--
      Project 02_04_02

      Author: George Rautio
      Date: November 27, 2017   

      Filename: PayCheck.php
   -->
<title>Paycheck Results</title>
</head>
<body style="background-color: gray">
<h1 style="text-align:center;">Paycheck Calculator</h1>
<?php
    
//Global variables that post the hours and wage
	$Hours = $_POST["hours"];
	$Wage = $_POST["wage"];
//if statment validation for $Hours and $Wage.
	if (is_numeric($Hours) && is_numeric($Wage)){
		
        if ( $Hours <= 40 ){
			$PayCheck = $Hours * $Wage;
			echo "<p style='color: blue; text-align: center'><strong>Your paycheck will be $$PayCheck</strong></p>";
		}
	
		if ( $Hours > 40 ){
			$PayCheck = ($Hours - 40) * ($Wage * 1.5);
			echo "<p style='color: blue; text-align: center'><strong>Your paycheck will be $$PayCheck</strong></p>";	
		}
	}
    
    else{
       echo "<strong>Please enter a vailid number</strong>";
    }
?>
<!--form the holds a button that will return  the user to the form-->
    <center>
    <form method="post" action="PayCheck.html">
    <input type="submit" name="Submit" value="Return to Form"/>
    </form>
    </center>
</body>
</html>
