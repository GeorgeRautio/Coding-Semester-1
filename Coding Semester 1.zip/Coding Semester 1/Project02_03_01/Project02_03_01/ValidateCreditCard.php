<html>

<head>
    <!--
      Project 02_03_01

      Author: George Rautio
      Date: November 7, 2017   

      Filename: ValidateCreditCard.php
   -->
    <title>Validate Credit Card</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Validate Credit Card</h2>
    <?php
// array that holds credt card numbers
    $creditCard = array("","8910-1234-5678-6543","0000-9123-4567-0123");
/
    foreach ($creditCard as $indexNumber => $cardNumber){
        if (empty($cardNumber)){
            echo "<p>Credit Card Number $indexNumber is invalid because it contains an empty string.</p>";
        }
 // else statment that replaces the - and the spaces and makes it all o ne number
        else{
            $creditCardNumber = $cardNumber;
            $creditCardNumber = str_replace("-","", $creditCardNumber);
            $creditCardNumber = str_replace(" ", "", $creditCardNumber);
            echo"<p>Credit Card Number $indexNumber $creditCardNumber removed dashes and spaces.</p>";
        if(!is_numeric($creditCardNumber)){
            echo"<p>Credit Card Number $indexNumber $creditCardNumber is invalid because it contains a non-numeric character.</p>";
        }
            else{
                echo"<p>Credit Card Number $indexNumber $creditCardNumber is a vaild Credit Card Number.</p>";
            }
        }
        
    }
    ?>

</body>

</html>
