<html>

<head>
    <!--
      Project 02_03_01

      Author: George Rautio
      Date: November 7, 2017   

      Filename: CompareStrings.php
   -->
    <title>Compare Strings</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Compare Strings</h2>
    <?php
//variables for the first and second string     
    $firstString = "Geek2Geek";
    $secondString = "Geezer2Geek";
// if statment with a nesed if statment that compares if the strings are the same    
    if (!empty($firstString) && !empty($secondString)){
        if($firstString == $secondString){
            echo "Both strings are the same.";
        }
//else stament that uses similar_text to see how meny charecters are in common  
//also in the else statment is the levenshtein() counts how meny carecters are needed  to make the text the same     
        else{
            echo "<p>Both strings have ". similar_text($firstString, $secondString)." characters(s) in common."."</p>";
            echo"<p>You must change ". levenshtein($firstString, $secondString)." characters(s) to make the strings the same.</p>";
        }
    }    
    else{
        echo "<p>Ethier the \$firstString variable or the \$secondString variable dose not contain a value so the two strings can not be compared.</p>";
    }
    ?>

</body>

</html>
