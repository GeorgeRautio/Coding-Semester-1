<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio
      Date: November 27, 2017   

      Filename: VisitorComments.php
   -->
    <title>Visitor Comments</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <?php    
    $dir = "./comments";
//$Dir var has a path as a string to the comments folder
    if (is_dir($dir)){
        if(isset($_POST['save'])){
            if (empty($_POST['name'])) {
                echo "Unkown visitor\n";
            }
            else{
                $saveString = stripslashes($_POST['name'] . "\n");
//$saveString uses the post method to display the name whitch also does not have any slashes             
                $saveString .= stripslashes($_POST['email'] . "\n");
//$saveString uses the post method to display the email whitch also does not have any slashes             
                $saveString .= date('r') . "\n";
//$saveString  displays the date
                $saveString .= stripslashes($_POST['comment'] . "\n");
//$saveString uses the post method to display the comment whitch also does not have any slashes             
                    echo "\$saveString: $saveString<br>";   
                    $currentTime = microtime();
// displays the current time in micro time format             
                    echo "\$currentTime: $currentTime<br>";                   
                $timeArray = explode(" ", $currentTime);
                echo var_dump($timeArray)."<br>";
// timeArray has a function called explode   displays the current time Array            
                
                    $timeStamp = (float)$timeArray[1] + (float)$timeArray[0];
                    echo "\$timeStamp: $timeStamp<br>";   
                    $saveFileName = "$dir/Comment.$timeStamp.txt";
                    echo "\$saveFileName: $saveFileName<br>";  
                if (file_put_contents($saveFileName, $saveString) > 0) {
                    echo"File \"". htmlentities($saveFileName)  . "\"successfully saved.<br>\n";

                }
                else{
// error message else
                    echo"There was an error writing \"". htmlentities($saveFileName)  ."\".<br>\n";
                }
            }
        }
        
    }
    else{
        echo "Directory dose not exist, creating it.<br>";
        mkdir($dir);
// makes the directory
    
        chmod($dir, 0777);
//change the directory permissions to read write and execute
    }
    ?>
    <h2>Visitor Comments</h2>

        <form action="VisitorComments.php" method="post">
            Your name: <input type="text" name="name"><br>
            Your email: <input type="email" name="email"><br>
            <textarea name="comment" rows="6" cols="100"></textarea><br>
            <input type="submit" name="save" value="Submit Your Comment"><br>
        </form>
</body>

</html>
