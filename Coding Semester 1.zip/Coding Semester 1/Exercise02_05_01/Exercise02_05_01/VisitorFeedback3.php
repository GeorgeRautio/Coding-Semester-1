<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio
      Date: November 27, 2017   

      Filename: VisitorFeedback3.php
   -->
    <title>Visitor Feedback 3</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Visitor Feedback 3</h2>
    <hr>
    <?php    
//$Dir var has a path as a string
    $dir = "./comments";
if(is_dir($dir)){
    $commentFiles = scandir($dir);
//scans the $dir directrory = the comments folder for anyfiles
    foreach ($commentFiles as $fileName){
        if (strcmp($fileName, ".")!== 0 && strcmp($fileName, "..")!== 0){
//takes the . and .. by using a strcmp            
                echo "From <strong>$fileName</strong><br>";
            $comment = file($dir . "/" . $fileName);
//prints the form,email and the date
            echo"Form: " . htmlentities($comment[0]) . "<br>\n";
            echo"Email address: " . htmlentities($comment[1]) . "<br>\n";
            echo"Date: " . htmlentities($comment[2]) . "<br>\n";
            $commentLines = count($comment);
            for($i = 3;$i<$commentLines; $i++){
                echo htmlentities($comment[$i]). "<br>\n";
  
            }
            echo "<hr>";
        }
    }
}
    ?>

</body>

</html>
