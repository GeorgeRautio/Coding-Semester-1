<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio
      Date: November 27, 2017   

      Filename: ViewFiles2.php
   -->
    <title>View Files 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>View Files 2</h2>
    <?php    
//$Dir var has a path as a string
    $dir = "../Exercise02_01_01";
    
    $dirEntries = scandir($dir);
    foreach ($dirEntries as $entry){
        // if statment removes the . and ..         
        if(strcmp($entry, '.')!== 0 && strcmp($entry, '..')!== 0){
        echo "<a href=\"$dir/$entry\">$entry</a><br>\n";
        }
        
    }
    
    
    
    
    
    ?>

</body>

</html>
