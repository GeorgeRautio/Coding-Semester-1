<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio
      Date: November 27, 2017   

      Filename: VisitorFeedback4.php
   -->
    <title>Visitor Feedback 4</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Visitor Feedback 4</h2>
    <hr>
    <?php    
//$Dir var has a path as a string
    $dir = "./comments";
if(is_dir($dir)){
    $commentFiles = scandir($dir);
    foreach ($commentFiles as $fileName){
        if (strcmp($fileName, ".")!== 0 && strcmp($fileName, "..")!== 0){
//scans the $dir directrory = the comments folder for anyfiles
                echo "From <strong>$fileName</strong><br>";
//file handle is opend
                $fileHandle = fopen($dir. "/" . $fileName, "rb");
            if($fileHandle === false){
                echo "There was an error reading file \"$fileName\".<br>\n";
            }
            
            else{
// gets the file form file handle
                $from = fgets($fileHandle);
                
// prints form, email and the date                
                echo"Form: ". htmlentities($from). "<br>\n";
                $email = fgets($fileHandle);
                echo"Email address: ". htmlentities($email). "<br>\n";
                $date = fgets($fileHandle);
                echo"Date: ". htmlentities($date). "<br>\n";
                $comment = "";
                while(!feof($fileHandle)){
                   $comment = fgets($fileHandle); 
                }
                $commentLines = count($comment);
                echo htmlentities($comment). "<br>\n";
        }
            echo "<hr>";
//closes the file and returns the file handle            
                fclose($fileHandle);
            }
                
        }
    }

    ?>

</body>

</html>
