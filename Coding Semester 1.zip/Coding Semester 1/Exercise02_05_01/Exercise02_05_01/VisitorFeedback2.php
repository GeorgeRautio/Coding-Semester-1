<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio
      Date: November 27, 2017   

      Filename: VisitorFeedback2.php
   -->
    <title>Visitor Feedback 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Visitor Feedback 2</h2>
    <hr>
    <?php    
//$Dir var has a path as a string
    $dir = "./comments";
if(is_dir($dir)){
    $commentFiles = scandir($dir);
//scans the $dir directrory = the comments folder for anyfiles
    foreach ($commentFiles as $fileName){
//foreach loop        
        if (strcmp($fileName, ".")!== 0 && strcmp($fileName, "..")!== 0){
//takes the . and .. by using a strcmp            
            echo "From <strong>$fileName</strong><br>";
            echo "<pre>\n";
// readfile function reads the contents of $dir and the file name          
          readfile($dir . "/" .$fileName);
            echo "</pre>\n";
            echo "<hr>";
        }
    }
}
    ?>

</body>

</html>
