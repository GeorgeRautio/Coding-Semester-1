<?php 
//$dir has a file path as its value
$dir = "../Exercise02_01_01";
if(isset($_GET['filename'])){
//$filetoget  is set to the current directory  and it is supposed to sritp any slashes form the file name/path
    $fileToGet = $dir ."/".stripslashes( $_GET['filename']);
    if(is_readable($fileToGet)){        
        header("Content-Description: File Transfer");
//This header function defines the content descripttion as file transfer
        header("Content-Type: appliction/force-download");
//This header function defines the content type as file/appliction and it is supposed to force-download the file
        header("Content-Disposition: attachment; filename=\"". $_GET['filename']. "\"");
//This header function defines the content disposition as a attachment then it gets the file name/path
        header("Content-Transfer-Encoding: base64");
//This header function defines the content Transfer-Encoding as base64 encoding type
        header("Content-Length: ". filesize($fileToGet));
//This header function defines the content lenght and has a function called fileszie to get the file size
        readfile($fileToGet);
        $errorMsg ="";
        $showErrorPage = false;// debug true, set to false
    }
    else{
        $errorMsg = "No file name specified";
        $showErrorPage = true;
        
    }
}
else{
  $errorMsg ="No filename specified";
    $showErrorPage= true;
}
if($showErrorPage){
    

?>

<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio
      Date: November 27, 2017   

      Filename: FileDownloader.php
   -->
    <title>File Download Error</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <p>There was an error downloading "<?php echo htmlentities($_GET['filename']); ?>"</p>
    <p><?php echo htmlentities($errorMsg); ?></p>
</body>

</html>
<?php 
}
?>