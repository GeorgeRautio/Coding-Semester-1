<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio

      Filename: BackupComments.php
   -->
    <title>Backup Comments</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Backup Comments</h2>
    <?php    
        $source = "./comments";
        $destination = "./backups";
    if(is_dir($destination)){
        if(is_dir($source)){
            $totalFiles = 0;
            $filesMoved = 0;
            $dirEntries = scandir($source);
            foreach($dirEntries as $entry){
                if($entry !== "." && $entry !==".."){
                  ++$totalFiles;
                    if(copy("$source/$entry","$destination/$entry")){
                        ++$filesMoved;
                    }
                    else{
                echo"could not move file \"" . htmlentities($entry)."\".<br>\n";
                    }
                }
            }
            echo "<p>$filesMoved of $totalFiles files successfully backed up.<br>\n</p>";
        }
        else{
            echo"Source directory\"$source\" does not exist, no backup to preform.<br>\n";  
 
        }
    }
    else{
        echo"Backup directory\"$destination\" does not exist, creating it.<br>\n";
        mkdir($destination);
        chmod($destination, 0777);
    }
    
    ?>

</body>

</html>
