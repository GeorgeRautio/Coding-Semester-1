<html>

<head>
    <!--
      Exercise 02_05_01

      Author: George Rautio
      Date: November 27, 2017   

      Filename: ViewFiles.php
   -->
    <title>View Files</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>View Files</h2>
    <?php    
//$Dir var has a path as a string
    $dir = "../Exercise02_01_01";
//$Opendir var holds the file handle    
    $openDir = opendir($dir);
//While loop that reads the files then dislays the file names
    while ($curFile = readdir($openDir)){
// if statment removes the . and ..         
        if(strcmp($curFile, '.')!== 0 && strcmp($curFile, '..')!== 0){
        echo "<a href=\"$dir/$curFile\">$curFile</a><br>\n";
        }
    }
//Returns the file handle to the os
    closedir($openDir);
    ?>

</body>

</html>
