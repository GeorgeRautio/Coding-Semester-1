<?php
$WeatherSource = "https://api.forecast.io/forecast/e5ad5a3262789c5cd2953e72b0c4224b/" .$_GET["lat"] . "," . $_GET["lng"];
header("Content-Type: application/json");
header("Cache-Control: no-cache");
readfile($WeatherSource);
?>
