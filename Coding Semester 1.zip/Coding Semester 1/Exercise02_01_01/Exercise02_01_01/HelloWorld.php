<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 11, 2017   

      Filename: HelloWorld.php
   -->
    <title>Hello World</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h1>Hello, World!</h1>

    <?php
//variable declaration    
    $worldVar = "world";
    $sunVar = "sun"; 
    $moonVar = "moon";
    $worldInfo = 92897000;
    $sunInfo = 72000000;
    $moonInfo = 3456;
// Shows hello world using a var.
    echo "<p>Hello $worldVar</br>";
// Outputs the miles from the earth to the sun.
    echo "The $worldVar is $worldInfo miles from the $sunVar<br>";
// Outputs Hello sun !
    echo "Hello ", $sunVar, "!<br>";
//Outputs the suns degrees in Fahrenhiet on the screen
    echo "The $sunVar's core temperture is approximately $sunInfo degrees Fahrenhiet.<br>";
// Outputs hello moon !  
    echo "Hello ", $moonVar, "!<br>";
// Outputs the moon miles in diamiter.    
    echo "The $moonVar is $moonInfo miles in diamiter.</p>";
// Shows the var on the screen beecause of the curly braces.     
    echo "This is a {$moonVar}embedded in double quotes";

//  echo "This is a $moonVarembedded in double quotes";
//                   ^   ^  ^
//                   |   |  |                         
// Brakes the the varible output because it is underfinded.
    ?>

</body>

</html>
