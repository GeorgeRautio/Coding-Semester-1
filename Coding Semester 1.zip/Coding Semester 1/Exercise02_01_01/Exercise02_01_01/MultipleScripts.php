<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 11, 2017   

      Filename: MultipleScripts.php
   -->
    <title>PHP Environment Info</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h1>PHP Environment Info</h1>
    <p>This page was rendered with PHP version
    <?php 
//This php section contains a function that returns the the php version as output on the screen.
     echo phpversion(); 
    ?>
    </p>
    
    <p>The PHP code was rendered with Zend Engine version
    <?php 
//This php section contains a function that returns the value of the Zend version.

     echo zend_version(); 
    ?>
    </p>
    
    <p>PHP's default MIME Type is
    <?php 
//This php section contains a function that returns the value from the ini.php file that returns the output of the defualt type from the inturpiter in this case .txt/.html extention.
     echo ini_get("default_mimetype"); 
    ?>
    </p>
    
    <p>The Maximum allowable exrcution time of a PHP script is
    <?php 
//This php section contains a function that returns the max exictuion time of the php file till it times out from the ini.php file.
    echo ini_get("max_execution_time"); 
    ?>
    seconds
    </p>

</body>

</html>



