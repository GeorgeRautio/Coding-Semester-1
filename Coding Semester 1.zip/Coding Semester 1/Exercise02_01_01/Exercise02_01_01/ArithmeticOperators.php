<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 16, 2017   

      Filename: ArithmeticOperators.php
   -->
    <title>Arithmetic Operators</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <?php
//addition expression   
    $x = 100;
    $y = 200;
    $returnValue = $x + $y;
    echo '<p>$returnValue after addition expression: ' . $returnValue . '</p>';
// subtraction expression   
    $x = 10;
    $y = 7;
    $returnValue = $x - $y;
    echo '<p>$returnValue after subtraction expression: ' . $returnValue . '</p>'; 
//multiplication expression   
    $x = 2;
    $y = 6;
    $returnValue = $x * $y;
    echo '<p>$returnValue after multiplication expression: ' . $returnValue . '</p>'; 
//division expression   
    $x = 24;
    $y = 3;
    $returnValue = $x / $y;
    echo '<p>$returnValue after division expression: ' . $returnValue . '</p>';   
//modulus expression 
    $x = 3;
    $y = 2;
    $returnValue = $x % $y;
    echo '<p>$returnValue after modulus expression: ' . $returnValue . '</p>';
//Unary Increment: Prefix notation for a student ID
    echo "<h2>Unary Increment: Prefix notation</h2>";
    $studentId = 100;
    $curStudentId = ++$studentId;
    echo "The first student ID is:  $curStudentId<br>";
    $curStudentId = ++$studentId;
    echo "The second student ID is:  $curStudentId<br>";
    $curStudentId = ++$studentId;
    echo "The third student ID is:  $curStudentId<br>";
//Unary Increment: Postfix notation for a student ID
    echo "<h2>Unary Increment: Postfix notation</h2>";
    $studentId = 100;
    $curStudentId = $studentId++;
    echo "The first student ID is:  $curStudentId<br>";
    $curStudentId = $studentId++;
    echo "The second student ID is:  $curStudentId<br>";
    $curStudentId = $studentId++;
    echo "The third student ID is:  $curStudentId <br>";
    ?>

</body>

</html>
