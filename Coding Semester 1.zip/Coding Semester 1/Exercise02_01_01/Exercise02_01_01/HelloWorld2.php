<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 11, 2017   

      Filename: HelloWorld2.php
   -->
    <title>Hello World 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h1>Hello, World 2</h1>

    <?php
//variable declaration    
    $worldVar = "world";
    $sunVar = "sun"; 
    $moonVar = "moon";
//constants
    define("WORLD_INFO", 92897000);
    define("SUN_INFO", 72000000);
    define("MOON_INFO", 3456);
// Shows hello world using a var.
    echo "<p>Hello $worldVar</br>";
// Outputs the miles from the earth to the sun.
    echo "The $worldVar is ",number_format(WORLD_INFO,0), " miles from the $sunVar<br>";
// Outputs Hello sun !
    echo "Hello ", $sunVar, "!<br>";
//Outputs the suns degrees in Fahrenhiet on the screen
    echo "The $sunVar's core temperture is approximately ", number_format(SUN_INFO,2)," degrees Fahrenhiet.<br>";
// Outputs hello moon !  
    echo "Hello ", $moonVar, "!<br>";
// Outputs the moon miles in diamiter.    
    echo "The $moonVar is " ,number_format(MOON_INFO,0), " miles in diamiter.</p>";
    ?>

</body>

</html>
