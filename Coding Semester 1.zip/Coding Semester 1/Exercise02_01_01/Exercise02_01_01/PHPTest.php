<!DOCTYPE html>
<html>

<head>
     <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 11, 2017   

      Filename: PHPTest.php
   -->
    <title>PHP Test</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h1>PHP Test</h1>
    <p>
    <?php
    phpinfo();
    ?>
    </p>

</body>

</html>