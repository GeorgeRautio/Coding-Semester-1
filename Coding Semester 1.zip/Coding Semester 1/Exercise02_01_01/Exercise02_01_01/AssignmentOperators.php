<html>

<head>
    <!--
      Exercise 02_01_01

      Author: George Rautio
      Date: October 16, 2017   

      Filename: AssignmentOperators.php
   -->
    <title>Assignment Operators</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <?php
    echo "<p>";

    echo"<h2>Compound Addition Assignment</h2>";
 // Compound addition
    $changingVar = 100;
    $changingVar += 50;
    echo "\$changingVar: $changingVar";
    
    
    echo"<h2>Compound Subtraction Assignment</h2>";
 // Compound Subtraction
    $changingVar -= 30;
    echo "\$changingVar: $changingVar"; 
    
    echo"<h2>Compound Division Assignment</h2>";
 // Compound Division
    $changingVar /=3 ;
    echo "\$changingVar: $changingVar"; 
    echo "<p>";
    ?>

</body>

</html>
