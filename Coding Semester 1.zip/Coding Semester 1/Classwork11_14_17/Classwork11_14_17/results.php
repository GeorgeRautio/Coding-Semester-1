<html>

<head>
    <!--
      classwork 11_14_17

      Author: George Rautio
      Date: November 14, 2017   

      Filename: results.php
   -->
    <title>Form Results</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
    
</head>

<body style="background-color:DimGrey; align-content: center;">
    <h1 style="text-align:center; color: black ; border-style:double; border-color: black;  border-width:11px; border-radius: 50px; padding: 10px 40px; width: 300px;">Superglobal Results Information</h1>
    <?php
    echo "<h2 style='text-align:center; border-width:8px; border-style:solid; border-color: black border-radius: 50px;  width: 400px;'></h2>";

    echo "<p><h1 style='text-color:blue; text-align:center;  border-width:11px; border-style:double; border-color:black; border-radius: 50px;  width: 400px;'> This server is built with: " .$_SERVER["SERVER_SOFTWARE"] ."</p>"."</h1>";

    echo "<p><h1 style='text-color:blue; text-align:center;  border-width:11px; border-style:double; border-color:black; border-radius: 50px; padding: 10px; width: 400px;'>The server protocol used is: ". $_SERVER["SERVER_PROTOCOL"] . "</p>"."</h1>";

    
     echo "<p><h1 style='text-color:blue; text-align:center;  border-width:11px; border-style:double; border-color:black; border-radius: 50px; padding: 10px; width: 400px;'>This server is hosted on the following Ip Address: ". $_SERVER["SERVER_NAME"] ."<h2 style='text-align:center; border-width:8px; border-style:solid; border-color: black;  width: 400px;'></h2> </p>". "</h1>"."<br>";

    ?>

</body>

</html>

<!---->
