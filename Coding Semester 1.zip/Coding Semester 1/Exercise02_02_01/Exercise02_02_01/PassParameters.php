<html>

<head>
    <!--
      Exercise 02_02_01

      Author: George Rautio
      Date: October 23, 2017   

      Filename: PassParameters.php
   -->
    <title>Pass Parameters</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Pass Parameters</h2>
    <?php
    //Pass Parameters section
//The function that increments the value of count by 1.   
    function incrementByValue($countByValue) {
        ++$countByValue;
        echo "<p>incrementByValue() value is: $countByValue</p>";
    }
//This function increments the copy of the value of count by 1.      
    function incrementByReference(&$countByReference) {
        ++$countByReference;
        echo "<p>incrementByReference() value is: $countByReference</p>";
    }
    
//Main program execution
    $count = 1;
    echo "<p>Main program starting value: $count.</p>";
    incrementByValue($count);
    echo "<p>Main program after incrementByValue() value: $count.</p>";
//Displays the function incrementByReference() as a copy that is why it has the value of 2.
    incrementByReference($count);
    echo "<p>Main program after incrementByReference() value: $count.</p>";
    ?>

    <?php
//Default Parameters section
    echo "<h2>Default Parameters</h2>";
//Function that has Default Parameters for the room and its colors.
    function paint($room = "office" , $color = "red"){
        return "<p>The color of the {$room} is {$color}.</p>";
    }
//echo paint("blue");
    echo paint();
    
//Overrides Default Parameters to bedroom is blue.
    echo paint("bedroom", "blue");
//Overrides Default Parameters to the bedroom is nothing.
    echo paint("bedroom", null);
//Displays The color of the bedroom is red.
    echo paint("bedroom");
//Inturpeter is not so smart displays The color of the blue is red.
    echo paint("blue");
    ?>

</body>

</html>
