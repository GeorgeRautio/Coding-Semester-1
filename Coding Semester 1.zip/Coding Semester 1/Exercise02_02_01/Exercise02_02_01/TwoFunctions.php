<html>

<head>
    <!--
      Exercise 02_02_01

      Author: George Rautio
      Date: October 20, 2017   

      Filename: TwoFunctions.php
   -->
    <title>Two Functions</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <?php
//This function displays a the first message.
    function displayMessage($firstMessage){
        echo "<p>$firstMessage</p>"; 
    }
//This function uses a return to return a string   
    function returnMessage(){
        return "<p>This message is being created and returned from a function</p>";
    }
    displayMessage("This message will be displayed from inside a function.");
//Displays second message   
    $returnValue = returnMessage(); 
    echo $returnValue;
//Shortcut method to display second message.
    echo returnMessage();
//Different way to do the same message    
    displayMessage(returnMessage());
    ?>

</body>

</html>
