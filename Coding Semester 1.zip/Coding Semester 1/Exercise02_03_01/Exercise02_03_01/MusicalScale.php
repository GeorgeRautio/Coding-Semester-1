<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: October 31, 2017   

      Filename: MusicalScale.php
   -->
    <title>Musical Scale</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Musical Scale</h2>
    <?php
// array that holds the musical scale    
    $musicalScale= array("do", "re", "mi", "fa", "so", "la", "ti");
    $outputString = "The notes of the musical scale are: ";
// foreach loop the edventually outputs the $outputString  and the $musicalScale array 
    foreach ($musicalScale as $currentNote){
        $outputString .= " " . $currentNote;
    }
    echo "<p>$outputString</p>";
    ?>

</body>

</html>
