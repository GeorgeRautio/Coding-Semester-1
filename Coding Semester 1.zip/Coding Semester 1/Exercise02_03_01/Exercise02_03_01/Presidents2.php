<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: November 2, 2017   

      Filename: Presidents2.php
   -->
    <title>Presidents 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Presidents 2</h2>
    <?php
//$presidents has the names of the first five presidents in a string seprated by a semicolin.
    $presidents = "George Washington;John Adams;Thomas Jefferson;James Madison;James Monroe";
// uses string token built in function  to get the semi colin and seperate the presidents names.    
    $thisPresident = strtok($presidents, ";");
// while loop that displays the list of presidents
    while($thisPresident !== NULL){
        echo "$thisPresident<br>";
        $thisPresident = strtok(";");
    }
    ?>

</body>

</html>
