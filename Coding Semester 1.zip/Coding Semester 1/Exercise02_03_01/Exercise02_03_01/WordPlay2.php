<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: November 1, 2017   

      Filename: WordPlay2.php
   -->
    <title>Word Play 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Word Play 2</h2>
    <?php
// Bad input someone gave us      
    $startingText = "mAdAm, i'M aDaM";
// The bad input converted to  all uppercase to match the name in the database
    $uppercaseText = strtoupper($startingText);
// The bad input converted to all lowercase to match the name in the database
    $lowercaseText = strtolower($startingText);
// Prints the uppercase var        
    echo "<p>$uppercaseText</p>";
// Prints the lowercase var            
    echo "<p>$lowercaseText</p>";
// Uppercases only the first character in the text
    echo "<p>" . ucfirst($lowercaseText) . "</p>\n";
// Lowercases only the first character in the text
    echo "<p>" . lcfirst($uppercaseText) . "</p>\n";
// Uppercases the first character in each word in the text  
    $workingText = ucwords($lowercaseText);
    echo "<p>$workingText</p>";
// md5 makes a jumbled the working text into random character  
    echo"<p>" . md5($workingText). "</p>\n";
// Show characters starting at zero and max six
    echo"<p>" . substr($workingText, 0, 6). "</p>\n";
// Shows seven characters
    echo"<p>" . substr($workingText, 7). "</p>\n";
// Reverses the text 
    echo"<p>" . strrev($workingText). "</p>\n";
// Shuffules the text randomly   
    echo"<p>" . str_shuffle($workingText). "</p>\n";
     ?>

</body>

</html>
