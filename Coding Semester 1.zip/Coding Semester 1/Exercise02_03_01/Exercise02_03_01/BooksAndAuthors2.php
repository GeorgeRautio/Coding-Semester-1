<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: November 1, 2017   

      Filename: BooksAndAuthors2.php
   -->
    <title>Books And Authors 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Books And Authors 2</h2>
    <?php
//The three arrys the hold the book and the authors and there real names     
    $books = array("The Adventure of Huckleberry Finn", "Nineteen Eighty-Four","Alice's andventures in wonderland", "Cat in the Hat");
    $authors = array("Mark Twain", "George Orwell", "Lewis Carrol", "Dr. Seuss");
    $realNames =array("Samuel Clemens", "Eric Blair", "Charles Dodson", "Theodor Geisel");
//For loop that shows the book , The lenght of the string from the book , The characters amount from the book
    for($i = 0; $i < count($books); $i++){
        echo "<p>The title \"{$books[$i]}\" contains ".  strlen($books[$i]) ." characters and ". str_word_count($books[$i]) . " words.</p>";
    }
    
    ?>

</body>

</html>
