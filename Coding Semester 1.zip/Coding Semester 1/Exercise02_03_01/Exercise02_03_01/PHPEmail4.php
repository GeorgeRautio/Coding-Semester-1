<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: November 6, 2017   

      Filename: PHPEmail4.php
   -->
    <title>PHP Email 4</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>PHP Email 4</h2>
    <?php
// Array with Mutiple rsndom emails
    $emailAddresses = array("john.smith@php.test", "mary.smith.mail@php.test","john.jones@php.invalid", "alan.smithee@test", "jsmith456@test","jsmith456@example.test", "mjones@example", "mjones@example.net", "jane.a.doe@example.org");
// Function that looks for a @ sign and a . to validate if the email is invalid
    function validateAddress($address){
        if (preg_match("/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[w-]+)*(\.[A-Za-z]{2,})$/i",$address) == 1) { 
            return true;
        }
        else {
            return false;
        }
    }
// Function that sorts through and finds the two invalid emails in the addresses array.
    function sortAddress($addresses){
            $sortedAddresses = array();
            $ilimit = count($addresses)-1;
            $jlimit = count($addresses);
        
        for ($i = 0; $i< $ilimit; $i++){
            $currentAddress = $addresses[$i];
        
        for ($j = $i +1; $j < $jlimit; $j++){
            if(strcasecmp($currentAddress,$addresses[$j]) > 0){
                $tempVal = $addresses[$j];    
                $addresses[$j]= $currentAddress;
                $currentAddress = $tempVal;
            }
        }
            $sortedAddresses[] = $currentAddress;
    }
        return($sortedAddresses);
}
// Prints all the emails using the implode 
    $sortedAddresses = sortAddress($emailAddresses);
    $sortedAddressList = implode(", ", $sortedAddresses);
    echo "<p>Sorted Addresses: $sortedAddressList</p>\n";

// Foreach loop that that echos the emails that are invalid
    foreach($sortedAddresses as $address){
        if (validateAddress($address) === false){
            echo "<p>The email address <em>$address</em> dose not appear to be valid. </p>";
        }
    }

    ?>

</body>

</html>