<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: November 3, 2017   

      Filename: PasswordFields2.php
   -->
    <title>Password Fields 2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Password Fields 2</h2>
    <?php
// varibel that holds a string with all the user info for the array     
    $record = "jdoe:8w4dso3a39yk2:1463:24: John Doe:/home/jdoe:/bin/bash:Be carefull this user, he cheats";
// array that has all the login placholders.    
    $passwordFields = array("login name","encrypted password","numerical user id", "numerical user group", "user name", "user home directory", "user command interpreter");
    
    $extraFields = 0;
    $fields = explode(":", $record);
    
//foreach using $key and $value    
    foreach ($fields as $key => $value){
        if($key < count($passwordFields)) {
            echo "<p>The {$passwordFields[$key]} is <em>$value</em></p>\n";
        }
        else{
            ++$extraFields;
            echo"<p>Extra field # $extraFields is <em>$value</em></p>\n";
        }
    }
    ?>

</body>

</html>
