<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: November 2, 2017   

      Filename: Presidents.php
   -->
    <title>Presidents</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Presidents</h2>
    <?php
//Two arrays the hold the first five presidents and the terms they served in office
    $presidents = array("George Washington", "John Adams", "Thomas Jefferson", "James Madison", "James Monroe");
    $yearsInOffice = array("1789 to 1797", "1797 to 1801", "1801 to 1809", "1809 to 1817" ,"1817 to 1825");
//Output Template that has place holders
    $outputTemplate = "<p>President [NAME] served from [TERM]</p>\n";    
//Foreach loop that replaces the place holder NAME and TERM with the names of the $presidents array and the therms served from the $yearsInOffice array
    foreach ($presidents as $key => $value){
        $tempString = str_replace("[NAME]", $value, $outputTemplate);
        $outputString = str_replace("[TERM]",$yearsInOffice[$key] ,$tempString); 
        echo $outputString;
    }
    ?>

</body>

</html>
