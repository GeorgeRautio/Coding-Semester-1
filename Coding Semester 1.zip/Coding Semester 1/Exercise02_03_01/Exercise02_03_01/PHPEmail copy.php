<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: November 1, 2017   

      Filename: PHPEmail.php
   -->
    <title>PHP Email</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>PHP Email</h2>
    <?php
// Array with Mutiple rsndom emails
    $emailAddresses = array("john.smith@php.test", "mary.smith.mail@php.test","john.jones@php.invalid", "alan.smithee@test", "jsmith456@test","jsmith456@example.test", "mjones@example", "mjones@example.net", "jane.a.doe@example.org");
// Function that looks for a @ sign and a . to validate if the email is invalid
    function validateAddress($address){
        if (strpos($address, '@')!== false && strpos($address, '.')) { 
            return true;
        }
        else {
            return false;
        }
    }
// Foreach loop that that echos the emails that are invalid
    foreach($emailAddresses as $address){
        if (validateAddress($address) === false){
            echo "<p>The email address <em>$address</em> dose not appear to be valid. </p>";
        }
    }
    ?>

</body>

</html>
