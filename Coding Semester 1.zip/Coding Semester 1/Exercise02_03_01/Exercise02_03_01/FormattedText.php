<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: October 31, 2017   

      Filename: FormattedText.php
   -->
    <title>Formatted Text</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Formatted Text</h2>
    <?php
//Using the <pre> tag to preformat the text we diplayed the text is formated useing the escape sequences.
    $displayValue = 9.876;
    echo "<pre>\n";
// \n – To add line breaks between string.
    echo "Unformatted text line 1. \r\n";
// \r – For carriage return.  and \n – To add line breaks between string.    
    echo "\tUnformatted text line 2. \r\n";
// \t – To add tab space. and \r – For carriage return.  and \n – To add line breaks between string.
    echo"\$displayValue = $displayValue";
// \$ – To escape $.
    echo "</pre>\n";
    
    
    ?>

</body>

</html>
