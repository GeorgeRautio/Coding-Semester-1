<html>

<head>
    <!--
      Exercise 02_03_01

      Author: George Rautio
      Date: October 31, 2017   

      Filename: BooksAndAuthors.php
   -->
    <title>Books And Authors</title>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
    <script src="modernizr.custom.65897.js"></script>
</head>

<body>
    <h2>Books And Authors</h2>
    <?php
//The three arrys the hold the book and the authors and there real names         
    $books = array("The Adventure of Huckleberry Finn", "Nineteen Eighty-Four","Alice's andventures in wonderland", "Cat in the Hat");
    $authors = array("Mark Twain", "George Orwell", "Lewis Carrol", "Dr. Seuss");
    $realNames =array("Samuel Clemens", "Eric Blair", "Charles Dodson", "Theodor Geisel");
//For loop that shows the real name of the author , The book , The and the pen name of the author of the book.
    for($i = 0; $i < count($books); $i++){
        echo "<p>The real name of {$authors[$i]}, " . "the author of \"{$books[$i]}\"," ." is {$realNames[$i]}.</p>";
    }
    
    ?>

</body>

</html>
