/*  Project 01_11_02

    Author: George Rautio
    Date:   

    Filename: script.js
*/

"use strict";
//global varibles
var httpRequest = false;
var entry = "^IXIC";


function getRequestObject() {
    try {
        httpRequest = new XMLHttpRequest();

    } catch (requestError) {
        return false;
    }

    return httpRequest;

}
//this function/if else statment stops the default on Submission
function stopSubmission(evt) {
    if (evt.preventDefault) {
        evt.preventDefault();
    } else {
        evt.returnValue = false;
    }
}
//This function gets the quote when the get quote button is clicked also to refresh the data after 10 seconds
function getQuote() {
    clearTimeout(updateQuote);
    var updateQuote = setTimeout('getQuote', 10000);
    if (document.getElementsByTagName("input")[0].value) {
        entry = document.getElementsByTagName("input")[0].value;



    }
    //AJAX Request
    if (!httpRequest) {
        httpRequest = getRequestObject();
        httpRequest.abort();
        httpRequest.open("get", "StockCheck.php?t=" + entry, true);
        httpRequest.send(null);
        httpRequest.onreadystatechange = displayData;
    }


}
//This function displays the data of the stock results on the screen
function displayData() {
    if (httpRequest.readyState === 4 && httpRequest.status === 200) {
        var stockResults = httpRequest.responseText;
        var stockItems = stockResults.split(/,|\"/);
        for (var i = stockItems.length - 1; i >= 0; i--) {
            if (stockItems[i] === "") {
                stockItems.splice(i, 1);
            }
        }
        // Gets data from the DOM for display
        document.getElementById("ticker").innerHTML = stockItems[0];
        document.getElementById("openingPrice").innerHTML = stockItems[6];
        document.getElementById("lastTrade").innerHTML = stockItems[1];
        document.getElementById("lastTradeDT").innerHTML = stockItems[2] + "," + stockItems[3];
        document.getElementById("change").innerHTML = stockItems[4];
        document.getElementById("range").innerHTML = (stockItems[8] * 1).toFixed(2) + "&ndash;" + (stockItems[7] * 1).toFixed(2);
        document.getElementById("volume").innerHTML = (stockItems[9] * 1).toLocaleString();
    }

}

function formatTable() {
    var rows = document.getElementsByTagName("tr");
    for (var i = 0; i < rows.length; i++) {
        rows[i].style.background = "9fe098";

    }
}
//Event handlers for submit and load
var form = document.getElementsByTagName("form")[0];
if (form.addEventListener) {
    form.addEventListener("submit", stopSubmission, false);
    window.addEventListener("load", formatTable, false);
    window.addEventListener("load", getQuote, false);

} else if (form.attachEvent) {
    form.attachEvent("onsubmit", stopSubmission);
    window.attachEvent("onload", formatTable);
    window.attachEvent("onload", getQuote);
}

if (window.addEventListener) {
    window.addEventListener("load", getQuote, false);
} else if (window.attachEvent) {
    window.attachEvent("onload", getQuote);

}
